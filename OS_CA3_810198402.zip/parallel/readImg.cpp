#include <iostream>
#include <unistd.h>
#include <fstream>
#include <vector>
#include <cmath>
#include <pthread.h>
#include <chrono>
#include "utils.hpp"

using namespace std;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;

#pragma pack(1)
#pragma once
#ifndef _read_img_cpp
#define _read_img_cpp
#define WriteOutFile "Image.bmp"

int rows;
int cols;
unsigned char** reds;
unsigned char** greens;
unsigned char** blues;
unsigned char** temp_reds;
unsigned char** temp_greens;
unsigned char** temp_blues;

typedef int LONG;
typedef unsigned short WORD;
typedef unsigned int DWORD;

typedef struct tagBITMAPFILEHEADER
{
    WORD bfType;
    DWORD bfSize;
    WORD bfReserved1;
    WORD bfReserved2;
    DWORD bfOffBits;
} BITMAPFILEHEADER, *PBITMAPFILEHEADER;

typedef struct tagBITMAPINFOHEADER
{
    DWORD biSize;
    LONG biWidth;
    LONG biHeight;
    WORD biPlanes;
    WORD biBitCount;
    DWORD biCompression;
    DWORD biSizeImage;
    LONG biXPelsPerMeter;
    LONG biYPelsPerMeter;
    DWORD biClrUsed;
    DWORD biClrImportant;
} BITMAPINFOHEADER, *PBITMAPINFOHEADER;


#endif

void RGB_Allocate(unsigned char**& dude) {
    dude = new unsigned char*[rows];
    for (int i = 0; i < rows; i++)
        dude[i] = new unsigned char[cols];
}


bool fillAndAllocate(char *&buffer, const char *fileName, int &rows, int &cols, int &bufferSize)
{
    std::ifstream file(fileName);

    if (file)
    {
        file.seekg(0, std::ios::end);
        std::streampos length = file.tellg();
        file.seekg(0, std::ios::beg);

        buffer = new char[length];
        file.read(&buffer[0], length);

        PBITMAPFILEHEADER file_header;
        PBITMAPINFOHEADER info_header;

        file_header = (PBITMAPFILEHEADER)(&buffer[0]);
        info_header = (PBITMAPINFOHEADER)(&buffer[0] + sizeof(BITMAPFILEHEADER));
        rows = info_header->biHeight;
        cols = info_header->biWidth;
        bufferSize = file_header->bfSize;
        return 1;
    }
    else
    {
        cout << "File" << fileName << " doesn't exist!" << endl;
        return 0;
    }
}

void getPixlesFromBMP24(unsigned char** reds, unsigned char** greens, unsigned char** blues, int end, int rows, int cols, char* FileReadBuffer) { // end is BufferSize (total size of file)
    int count = 1;
    int extra = cols % 4; // The nubmer of bytes in a row (cols) will be a multiple of 4.
    for (int i = 0; i < rows; i++){
        count += extra;
        for (int j = cols - 1; j >= 0; j--)
            for (int k = 0; k < 3; k++) {
                switch (k) {
                    case 0:
                        reds[i][j] = FileReadBuffer[end - count++];
                        temp_reds[i][j] = reds[i][j];
                        break;
                    case 1:
                        greens[i][j] = FileReadBuffer[end - count++];
                        temp_greens[i][j] = greens[i][j];
                        break;
                    case 2:
                        blues[i][j] = FileReadBuffer[end - count++];
                        temp_blues[i][j] = blues[i][j];
                        break;
                }
            }
    }
}

void writeOutBmp24(char* FileBuffer, const char* NameOfFileToCreate, int BufferSize) {
    std::ofstream write(NameOfFileToCreate);
    if (!write) {
        cout << "Failed to write " << NameOfFileToCreate << endl;
        return;
    }
    int count = 1;
    int extra = cols % 4; // The nubmer of bytes in a row (cols) will be a multiple of 4.
    for (int i = 0; i < rows; i++){
        count += extra;
        for (int j = cols - 1; j >= 0; j--)
            for (int k = 0; k < 3; k++) {
                switch (k) {
                    case 0: //reds
                        FileBuffer[BufferSize - count] = reds[i][j];
                        break;
                    case 1: //green
                        FileBuffer[BufferSize - count] = greens[i][j];
                        break;
                    case 2: //blue
                        FileBuffer[BufferSize - count] = blues[i][j];
                        break;
                }
                count++;
            }
    }
    write.write(FileBuffer, BufferSize);
}




int main(int argc, char *argv[])
{
    auto start_time = std::chrono::high_resolution_clock::now();
    char *fileBuffer;
    int bufferSize;
    char *fileName = argv[1];
    if (!fillAndAllocate(fileBuffer, fileName, rows, cols, bufferSize))
    {
        cout << "File read error" << endl;
        return 1;
    }
    RGB_Allocate(reds);
    RGB_Allocate(greens);
    RGB_Allocate(blues);

    RGB_Allocate(temp_reds);
    RGB_Allocate(temp_greens);
    RGB_Allocate(temp_blues);
    getPixlesFromBMP24( reds,  greens, blues,bufferSize, rows, cols, fileBuffer);
//    readPixels()

    blur();
    sepia();
    washedOut();
    multipleSign();

    writeOutBmp24(fileBuffer,  WriteOutFile,bufferSize);
    auto stop_time = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop_time - start_time);
    std::cout <<  duration.count() << std::endl;
    return 1;

}