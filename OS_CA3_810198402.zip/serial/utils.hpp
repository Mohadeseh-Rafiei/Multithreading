#ifndef _Utils_hpp_
#define _Utils_hpp_

bool ok(int i, int j, int rows, int cols);
void mean(float *r_mean, float *g_mean, float *b_mean, int rows, int cols, unsigned char **reds, unsigned char **greens, unsigned char **blues);

#endif